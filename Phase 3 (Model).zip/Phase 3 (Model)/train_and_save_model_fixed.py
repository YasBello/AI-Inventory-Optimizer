# train_and_save_model_fixed.py
# Trains a RandomForestRegressor on walmart_preprocessed.csv and saves final_model.pkl

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.ensemble import RandomForestRegressor
from math import sqrt
import joblib
import os

DATA_PATH = 'walmart_preprocessed.csv'
MODEL_PATH = 'final_model.pkl'

def load_data(path):
    df = pd.read_csv(path)
    # Ensure essential columns exist; if one-hot columns are missing, add as zeros
    required = ['Weekly_Sales','Store','Dept','Size','Temperature','Fuel_Price','CPI','Unemployment',
                'Total_MarkDown','Month','Week','DayOfWeek','IsWeekend']
    for col in ['Type_B','Type_C','IsHoliday_True']:
        if col not in df.columns:
            df[col] = 0

    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    return df

def train_and_evaluate(df):
    feature_cols = ['Store','Dept','Size','Temperature','Fuel_Price','CPI','Unemployment',
                    'Total_MarkDown','Month','Week','DayOfWeek','IsWeekend',
                    'Type_B','Type_C','IsHoliday_True']
    X = df[feature_cols]
    y = df['Weekly_Sales']

    # 80/20 split without shuffling (time order respected)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, shuffle=False)

    rf = RandomForestRegressor(
        n_estimators=300,
        max_depth=None,
        min_samples_split=2,
        min_samples_leaf=1,
        n_jobs=-1,
        random_state=42
    )
    rf.fit(X_train, y_train)
    preds = rf.predict(X_test)

    mae = mean_absolute_error(y_test, preds)
    rmse = sqrt(mean_squared_error(y_test, preds))
    r2 = r2_score(y_test, preds)
    print(f"Random Forest -> MAE: {mae:,.2f} | RMSE: {rmse:,.2f} | R^2: {r2:.4f}")

    joblib.dump(rf, MODEL_PATH)
    print(f"Saved trained model to: {MODEL_PATH}")

    # Optional: export predictions
    out = X_test.copy()
    out['y_true'] = y_test.values
    out['y_pred'] = preds
    out.to_csv('test_predictions.csv', index=False)
    print("Wrote test_predictions.csv")

if __name__ == '__main__':
    if not os.path.exists(DATA_PATH):
        raise FileNotFoundError(f"{DATA_PATH} not found. Place the preprocessed CSV in this folder and rerun.")
    df = load_data(DATA_PATH)
    train_and_evaluate(df)
